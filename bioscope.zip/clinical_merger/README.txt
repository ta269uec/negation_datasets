Please download the raw clinical files ("Challenge Testing Data - CODES, 2007" and "Challenge Training Data, 2007") from:
http://www.computationalmedicine.org/catalog

Run def_name_merger.bat. It uses the appropiate file names as the arguments of the merger.bat and outputs the scope-annotated out.xml.
